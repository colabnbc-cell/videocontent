
export interface ScriptItem {
  shotDescription: string;
  onScreenText: string;
  duration: number;
}

export interface PlatformContent {
  title: string;
  script: ScriptItem[];
  caption: string;
  hashtags: string[];
  videoFormat: string;
}

export interface SocialContentPlan {
  websiteStory: string;
  facebook: PlatformContent;
  instagramReel: PlatformContent;
  instagramStory: PlatformContent;
  instagramPost: PlatformContent;
  tiktok: PlatformContent;
  youtubeShorts: PlatformContent;
  twitter: PlatformContent;
  linkedin: PlatformContent;
  telegram: PlatformContent;
}
