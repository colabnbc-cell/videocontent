import React, { useState, useCallback } from 'react';
import { FileUpload } from './components/FileUpload';
import { ResultDisplay } from './components/ResultDisplay';
import { Loader } from './components/Loader';
import { analyzeVideoAndGenerateContent } from './services/geminiService';
import { extractFramesFromVideo } from './utils/videoProcessor';
import type { SocialContentPlan } from './types';

const App: React.FC = () => {
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [loadingMessage, setLoadingMessage] = useState<string>('');
  const [generatedContent, setGeneratedContent] = useState<SocialContentPlan | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [frameCount, setFrameCount] = useState<number>(30);


  const handleFileSelect = (file: File | null) => {
    setVideoFile(file);
    setGeneratedContent(null);
    setError(null);
  };
  
  const handleFrameCountChange = (count: number) => {
    setFrameCount(count);
  };

  const handleAnalysis = useCallback(async () => {
    setError(null);
    setGeneratedContent(null);
    setIsLoading(true);

    try {
        if (!videoFile) {
          throw new Error('Please select a video file first.');
        }

        setLoadingMessage(`Extracting ${frameCount} frames from video...`);
        const frames = await extractFramesFromVideo(videoFile, frameCount);

        if (frames.length === 0) {
          throw new Error('Could not extract any frames from the video. The file might be corrupted or in an unsupported format.');
        }

        setLoadingMessage('AI is analyzing the video and generating content...');
        const content = await analyzeVideoAndGenerateContent(frames);
        setGeneratedContent(content);
      
    } catch (err) {
      console.error(err);
      setError(err instanceof Error ? err.message : 'An unknown error occurred.');
    } finally {
      setIsLoading(false);
      setLoadingMessage('');
    }
  }, [videoFile, frameCount]);
  
  const handleReset = () => {
    setVideoFile(null);
    setGeneratedContent(null);
    setError(null);
    setIsLoading(false);
  };

  return (
    <div className="min-h-screen bg-slate-900 text-gray-200 font-sans p-4 sm:p-6 lg:p-8">
      <div className="max-w-6xl mx-auto">
        <header className="text-center mb-8">
          <h1 className="text-4xl sm:text-5xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-sky-400 to-blue-600">
            Video Content Strategist AI
          </h1>
          <p className="mt-2 text-lg text-slate-400">
            حوّل فيديوهاتك إلى محتوى جاهز للنشر على جميع المنصات
          </p>
        </header>

        <main>
          {isLoading ? (
            <Loader message={loadingMessage} />
          ) : generatedContent ? (
             <ResultDisplay content={generatedContent} onReset={handleReset} />
          ) : (
            <FileUpload 
              selectedFile={videoFile} 
              onFileSelect={handleFileSelect} 
              onAnalysis={handleAnalysis}
              frameCount={frameCount}
              onFrameCountChange={handleFrameCountChange}
            />
          )}

          {error && (
            <div className="mt-6 bg-red-900/50 border border-red-700 text-red-300 px-4 py-3 rounded-lg text-center" role="alert">
              <p className="font-bold">Error</p>
              <p>{error}</p>
            </div>
          )}
        </main>
      </div>
       <footer className="text-center mt-12 text-slate-500 text-sm">
          <p>Powered by Google Gemini</p>
        </footer>
    </div>
  );
};

export default App;