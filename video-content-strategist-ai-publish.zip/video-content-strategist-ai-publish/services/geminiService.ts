import { GoogleGenAI, Type } from '@google/genai';
import type { SocialContentPlan } from '../types';

const platformContentSchema = {
    type: Type.OBJECT,
    properties: {
        title: { type: Type.STRING, description: "A catchy title for the video in Arabic." },
        script: {
            type: Type.ARRAY,
            description: "An array of objects, where each object represents a scene or shot. Include visual description and suggested Arabic text on screen.",
            items: {
                type: Type.OBJECT,
                properties: {
                    shotDescription: { type: Type.STRING, description: "A description of the visual shot in Arabic." },
                    onScreenText: { type: Type.STRING, description: "Suggested text to display on screen in Arabic." },
                    duration: { type: Type.NUMBER, description: "Suggested duration in seconds for this shot." }
                },
                required: ["shotDescription", "onScreenText", "duration"]
            }
        },
        caption: { type: Type.STRING, description: "An engaging caption for the post in Arabic." },
        hashtags: {
            type: Type.ARRAY,
            description: "An array of relevant hashtags in Arabic.",
            items: { type: Type.STRING }
        },
        videoFormat: { type: Type.STRING, description: "Recommended video format and aspect ratio for this platform (e.g., 'Vertical 9:16', 'Square 1:1')." }
    },
    required: ["title", "script", "caption", "hashtags", "videoFormat"]
};

const responseSchema = {
    type: Type.OBJECT,
    properties: {
        websiteStory: {
            type: Type.STRING,
            description: "A full narrative story based on the video, written in an engaging style in Arabic, suitable for a website or blog post."
        },
        facebook: platformContentSchema,
        instagramReel: platformContentSchema,
        instagramStory: platformContentSchema,
        instagramPost: platformContentSchema,
        tiktok: platformContentSchema,
        youtubeShorts: platformContentSchema,
        twitter: platformContentSchema,
        linkedin: platformContentSchema,
        telegram: platformContentSchema,
    },
    required: [
        "websiteStory", "facebook", "instagramReel", "instagramStory", "instagramPost",
        "tiktok", "youtubeShorts", "twitter", "linkedin", "telegram"
    ]
};

export const analyzeVideoAndGenerateContent = async (frames: string[]): Promise<SocialContentPlan> => {
    if (!process.env.API_KEY) {
        throw new Error("API_KEY environment variable not set.");
    }
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

    const imageParts = frames.map(frame => ({
        inlineData: {
            mimeType: 'image/jpeg',
            data: frame,
        },
    }));

    const prompt = `
    You are an expert social media video strategist and content creator. Analyze the following sequence of frames from a video.
    Based on the visual content, generate a comprehensive content plan for various social media platforms.
    The entire response, including all text, descriptions, captions, and hashtags, MUST be in Arabic.
    Your response must strictly adhere to the provided JSON schema. Do not output anything other than the JSON object.

    Here is the list of platforms to generate content for:
    - Facebook
    - Instagram Reel
    - Instagram Story
    - Instagram Post
    - TikTok
    - YouTube Shorts
    - X (Twitter)
    - LinkedIn
    - Telegram
    - A full narrative story for a Website/Blog
    `;

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: { parts: [...imageParts, { text: prompt }] },
        config: {
            responseMimeType: "application/json",
            responseSchema: responseSchema,
        },
    });
    
    const jsonText = response.text.trim();
    try {
        const parsedJson = JSON.parse(jsonText);
        return parsedJson as SocialContentPlan;
    } catch (e) {
        console.error("Failed to parse JSON response:", jsonText);
        throw new Error("The AI returned an invalid response format. Please try again.");
    }
};