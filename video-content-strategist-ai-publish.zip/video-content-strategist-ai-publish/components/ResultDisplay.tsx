
import React, { useState } from 'react';
import type { SocialContentPlan, PlatformContent } from '../types';
import { CopyIcon } from './icons/CopyIcon';

interface ResultDisplayProps {
  content: SocialContentPlan;
  onReset: () => void;
}

type PlatformKey = keyof Omit<SocialContentPlan, 'websiteStory'>;

const PLATFORM_NAMES: Record<PlatformKey, string> = {
  facebook: 'Facebook',
  instagramReel: 'Instagram Reel',
  instagramStory: 'Instagram Story',
  instagramPost: 'Instagram Post',
  tiktok: 'TikTok',
  youtubeShorts: 'YouTube Shorts',
  twitter: 'X (Twitter)',
  linkedin: 'LinkedIn',
  telegram: 'Telegram',
};

const CopyButton: React.FC<{ textToCopy: string }> = ({ textToCopy }) => {
    const [copied, setCopied] = useState(false);
    const handleCopy = () => {
        navigator.clipboard.writeText(textToCopy);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    };

    return (
        <button onClick={handleCopy} className="absolute top-2 right-2 p-1.5 bg-slate-600/50 rounded-md hover:bg-slate-500/50 transition-colors">
            <CopyIcon className="w-4 h-4" />
            {copied && <span className="absolute -top-7 right-0 text-xs bg-sky-500 text-white px-2 py-0.5 rounded">Copied!</span>}
        </button>
    );
};

const PlatformContentDisplay: React.FC<{ content: PlatformContent }> = ({ content }) => (
    <div className="space-y-6">
        <div>
            <h3 className="text-xl font-bold text-sky-400 mb-2">Title</h3>
            <p className="text-slate-300">{content.title}</p>
        </div>
        <div>
            <h3 className="text-xl font-bold text-sky-400 mb-2">Recommended Format</h3>
            <p className="text-slate-300">{content.videoFormat}</p>
        </div>
        <div>
            <h3 className="text-xl font-bold text-sky-400 mb-2">Caption</h3>
             <div className="relative bg-slate-900/70 p-4 rounded-lg border border-slate-700 whitespace-pre-wrap">
                <p className="text-slate-300">{content.caption}</p>
                <CopyButton textToCopy={content.caption} />
            </div>
        </div>
        <div>
            <h3 className="text-xl font-bold text-sky-400 mb-2">Hashtags</h3>
            <div className="relative bg-slate-900/70 p-4 rounded-lg border border-slate-700">
                <p className="text-slate-300 font-mono text-sm">{content.hashtags.join(' ')}</p>
                <CopyButton textToCopy={content.hashtags.join(' ')} />
            </div>
        </div>
        <div>
            <h3 className="text-xl font-bold text-sky-400 mb-2">Script</h3>
            <div className="space-y-4">
                {content.script.map((item, index) => (
                    <div key={index} className="bg-slate-800 p-4 rounded-lg border border-slate-700">
                        <p className="font-semibold text-slate-300">Shot {index + 1} <span className="text-xs font-normal text-slate-400">({item.duration}s)</span></p>
                        <p className="mt-1 text-sm text-slate-400"><span className="font-medium text-slate-300">Visual:</span> {item.shotDescription}</p>
                        <p className="mt-1 text-sm text-slate-400"><span className="font-medium text-slate-300">On-screen Text:</span> {item.onScreenText || 'None'}</p>
                    </div>
                ))}
            </div>
        </div>
    </div>
);

export const ResultDisplay: React.FC<ResultDisplayProps> = ({ content, onReset }) => {
  const platforms = Object.keys(PLATFORM_NAMES) as PlatformKey[];
  const [activeTab, setActiveTab] = useState<PlatformKey | 'websiteStory'>(platforms[0]);

  return (
    <div className="bg-slate-800/50 rounded-2xl border border-slate-700 shadow-lg p-4 sm:p-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
        <h2 className="text-2xl font-bold text-white mb-3 sm:mb-0">Your Content Plan</h2>
        <button 
          onClick={onReset}
          className="px-4 py-2 text-sm font-semibold text-white bg-slate-600 rounded-lg hover:bg-slate-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-800 focus:ring-sky-500 transition-all duration-200"
        >
          Analyze Another Video
        </button>
      </div>

      <div className="flex border-b border-slate-600 overflow-x-auto">
        {['websiteStory', ...platforms].map(key => (
          <button
            key={key}
            onClick={() => setActiveTab(key as PlatformKey | 'websiteStory')}
            className={`px-4 py-2 -mb-px text-sm font-medium transition-colors duration-200 whitespace-nowrap ${
              activeTab === key
                ? 'border-b-2 border-sky-400 text-sky-400'
                : 'border-b-2 border-transparent text-slate-400 hover:text-white'
            }`}
          >
            {key === 'websiteStory' ? 'Website Story' : PLATFORM_NAMES[key as PlatformKey]}
          </button>
        ))}
      </div>
      <div className="mt-6">
        {activeTab === 'websiteStory' ? (
           <div className="space-y-4">
                <h3 className="text-xl font-bold text-sky-400">Website/Blog Post Story</h3>
                <div className="relative bg-slate-900/70 p-4 rounded-lg border border-slate-700 whitespace-pre-wrap leading-relaxed">
                    <p className="text-slate-300">{content.websiteStory}</p>
                    <CopyButton textToCopy={content.websiteStory} />
                </div>
            </div>
        ) : (
            <PlatformContentDisplay content={content[activeTab]} />
        )}
      </div>
    </div>
  );
};
