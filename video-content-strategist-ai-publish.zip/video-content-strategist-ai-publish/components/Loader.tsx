
import React from 'react';

interface LoaderProps {
  message: string;
}

export const Loader: React.FC<LoaderProps> = ({ message }) => {
  return (
    <div className="flex flex-col items-center justify-center p-10 bg-slate-800/50 rounded-2xl border border-slate-700">
      <div className="w-16 h-16 border-4 border-dashed rounded-full animate-spin border-sky-400"></div>
      <p className="mt-4 text-lg text-slate-300 text-center">{message}</p>
    </div>
  );
};
