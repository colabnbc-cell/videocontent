import React, { useCallback, useState, useEffect } from 'react';
import { VideoIcon } from './icons/VideoIcon';

interface FileUploadProps {
  onFileSelect: (file: File | null) => void;
  onAnalysis: () => void;
  selectedFile: File | null;
  frameCount: number;
  onFrameCountChange: (count: number) => void;
}

export const FileUpload: React.FC<FileUploadProps> = ({ 
  onFileSelect, 
  onAnalysis, 
  selectedFile,
  frameCount,
  onFrameCountChange
 }) => {
  const [isDragging, setIsDragging] = useState(false);
  const [videoPreviewUrl, setVideoPreviewUrl] = useState<string | null>(null);

  useEffect(() => {
    if (selectedFile) {
      const url = URL.createObjectURL(selectedFile);
      setVideoPreviewUrl(url);

      return () => {
        URL.revokeObjectURL(url);
        setVideoPreviewUrl(null);
      };
    }
  }, [selectedFile]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      onFileSelect(e.target.files[0]);
    }
    e.target.value = '';
  };

  const handleDragEnter = useCallback((e: React.DragEvent<HTMLLabelElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent<HTMLLabelElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  }, []);

  const handleDragOver = useCallback((e: React.DragEvent<HTMLLabelElement>) => {
    e.preventDefault();
    e.stopPropagation();
  }, []);

  const handleDrop = useCallback((e: React.DragEvent<HTMLLabelElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      onFileSelect(e.dataTransfer.files[0]);
    }
  }, [onFileSelect]);

  const handleRemoveFile = () => {
    onFileSelect(null);
  }

  return (
    <div className="max-w-2xl mx-auto bg-slate-800/50 rounded-2xl border border-slate-700 shadow-lg p-6 sm:p-8 text-center">
      
        {!selectedFile ? (
          <>
            <h2 className="text-xl font-semibold text-slate-200 mb-4">Upload Your Video</h2>
            <label
              htmlFor="video-upload"
              onDragEnter={handleDragEnter}
              onDragLeave={handleDragLeave}
              onDragOver={handleDragOver}
              onDrop={handleDrop}
              className={`flex flex-col items-center justify-center w-full h-64 border-2 border-dashed rounded-lg cursor-pointer transition-colors duration-300 ${isDragging ? 'border-sky-400 bg-slate-700/50' : 'border-slate-600 hover:border-slate-500 hover:bg-slate-800/70'}`}
            >
              <div className="flex flex-col items-center justify-center pt-5 pb-6">
                <VideoIcon className="w-12 h-12 mb-4 text-slate-500" />
                <p className="mb-2 text-sm text-slate-400">
                  <span className="font-semibold text-sky-400">Click to upload</span> or drag and drop
                </p>
                <p className="text-xs text-slate-500">MP4, MOV, AVI, WMV or other video formats</p>
              </div>
              <input id="video-upload" type="file" className="hidden" accept="video/*" onChange={handleFileChange} />
            </label>
          </>
        ) : (
          <div className="space-y-6">
              <div>
                <h2 className="text-xl font-semibold text-slate-200 mb-4">Video Preview</h2>
                {videoPreviewUrl && (
                    <video src={videoPreviewUrl} controls className="w-full max-h-[400px] rounded-lg bg-black" />
                )}
                <div className="mt-4 text-center bg-slate-700/50 p-3 rounded-lg flex items-center justify-between">
                    <p className="font-mono text-sky-300 break-all text-left">{selectedFile.name}</p>
                    <button 
                        onClick={handleRemoveFile} 
                        className="ml-4 px-3 py-1 text-xs font-semibold text-white bg-red-600 rounded-md hover:bg-red-700 transition-colors"
                    >
                        Remove
                    </button>
                </div>
              </div>

              <div className="text-left space-y-2 pt-4 border-t border-slate-700">
                <label htmlFor="frameCount" className="block text-sm font-medium text-slate-300">
                    Analysis Depth (Number of Frames)
                </label>
                <div className="flex items-center space-x-4">
                    <input
                        id="frameCount"
                        type="range"
                        min="5"
                        max="60"
                        value={frameCount}
                        onChange={(e) => onFrameCountChange(Number(e.target.value))}
                        className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-sky-500"
                    />
                    <span className="text-lg font-semibold text-sky-400 w-12 text-center">{frameCount}</span>
                </div>
              </div>
          </div>
        )}

      <div className="mt-8">
        <button
          onClick={onAnalysis}
          disabled={!selectedFile}
          className="w-full sm:w-auto px-12 py-3 text-base font-semibold text-white bg-gradient-to-r from-sky-500 to-blue-600 rounded-lg shadow-md hover:from-sky-600 hover:to-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-900 focus:ring-sky-500 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300 transform hover:scale-105"
        >
          Analyze Video
        </button>
      </div>
    </div>
  );
};