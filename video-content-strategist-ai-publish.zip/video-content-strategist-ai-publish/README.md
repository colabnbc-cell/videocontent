<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://github.com/user-attachments/assets/0aa67016-6eaf-458a-adb2-6e31a0763ed6" />
</div>

# Video Content Strategist AI

This repository contains a complete React application that uses Google’s Gemini API to analyze a short video and automatically generate a tailored content plan in Arabic for multiple social‑media platforms.  The app extracts a set number of frames from an uploaded video and sends them, along with a prompt, to the Gemini model.  The response includes platform‑specific titles, scripts, captions, hashtag suggestions, format recommendations and a long‑form story suitable for a blog or website.

## Features

* **Upload any video file** (mp4, mov, avi, wmv, etc.) directly in the browser.
* **Flexible frame analysis** – choose how many frames (between 5 and 60) to extract for analysis.
* **Automatic content generation** – receive a JSON plan covering Facebook, Instagram (Reel, Story and Post), TikTok, YouTube Shorts, X (Twitter), LinkedIn, Telegram and a full article.
* **Built with React 19 and Vite** for a fast, modern development experience.
* **Styled with Tailwind CSS** for a clean, responsive UI.

## Prerequisites

To run or build the application you need:

* **Node.js** (version 18 or higher) and **npm** installed on your machine.
* A **Google Gemini API key**.  You can generate one via the Google AI Studio console.  This key is required to authenticate requests to the Gemini API and must be kept secret.  _Do not commit it to version control._

## Getting Started

1. **Install dependencies**

   Run the following command in the root of the project to install all Node dependencies:

   ```bash
   npm install
   ```

   When working on your own machine or CI environment you must have internet access to fetch the `@google/genai` package and other dependencies.  (This environment cannot install that package, but your local machine can.)

2. **Create an `.env.local` file**

   In the root of the project there is a file named `.env.local`.  Replace the placeholder value with your actual Gemini API key:

   ```env
   GEMINI_API_KEY=YOUR_ACTUAL_GOOGLE_GEMINI_API_KEY
   ```

   The Vite configuration injects this value as both `process.env.GEMINI_API_KEY` and `process.env.API_KEY`, so the client‑side code can read it at build time.  If you plan to deploy the app, configure your hosting provider to supply this environment variable securely (e.g. using Netlify/Vercel environment variables).

3. **Run the app in development mode**

   Start the Vite development server:

   ```bash
   npm run dev
   ```

   The application will be available at `http://localhost:3000/` by default.  You can upload a video, adjust the frame count and generate a content plan.  Keep an eye on your browser console for any errors during development.

## Building for Production

To produce an optimized build for deployment, run:

```bash
npm run build
```

This command outputs a static site into a `dist` folder.  You can preview the build locally with:

```bash
npm run preview
```

## Deploying

Because this is a pure front‑end application, you can deploy the contents of the `dist` directory to any static hosting provider (Netlify, Vercel, Firebase Hosting, GitHub Pages, Cloudflare Pages, etc.).  Here is a general deployment workflow:

1. **Commit your code** to a Git repository (GitHub/GitLab/Bitbucket).
2. **Configure environment variables** (`GEMINI_API_KEY`) in your hosting provider’s dashboard.  Most providers have a way to securely store environment variables that will be injected at build time.
3. **Connect your repository** to the hosting provider and select the build command `npm run build` and the output directory `dist`.
4. **Deploy**.  The provider will install dependencies, build the project and serve the static files.

Alternatively, you can run `npm run build` locally and manually upload the contents of `dist` to your server or a static file hosting service.

## What We Need From You

To complete the deployment and make everything work correctly we will need:

* **Your Google Gemini API key** – please provide this key or set it yourself in the `.env.local` file or through your hosting provider’s environment‑variable settings.
* **Your chosen hosting platform** – Netlify, Vercel or another service.  Each platform has slightly different configuration steps; let us know your preference and we can tailor the deployment instructions accordingly.

## Caveats

* The `@google/genai` SDK (used in `services/geminiService.ts`) is not included in this environment because it requires internet access to download.  When you install dependencies in your own environment the package will be fetched automatically.
* API keys should **never** be committed to version control or exposed publicly.  Use environment variables provided by your hosting platform to supply them securely at build and runtime.
* If you wish to hide the API key from the client entirely, consider creating a simple back‑end or serverless function that acts as a proxy.  The proxy would accept frame data from the client, call the Gemini API using the secret key, and return the content plan.  This pattern prevents exposing the key to the browser.

## Resources

* [Google AI Studio](https://aistudio.google.com/) – obtain your API key and experiment with the Gemini models.
* [Vite Documentation](https://vitejs.dev/) – learn more about the tooling used in this project.
* [Tailwind CSS Documentation](https://tailwindcss.com/docs) – customize the styling.

We hope this app helps you transform your videos into engaging social‑media content!
