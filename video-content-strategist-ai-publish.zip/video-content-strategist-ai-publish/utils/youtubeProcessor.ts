interface YouTubeMetadata {
  title: string;
  author_name: string;
  thumbnail_url: string;
}

export const fetchYouTubeMetadata = async (url: string): Promise<YouTubeMetadata> => {
  try {
    // Using a public oEmbed proxy to bypass CORS issues in a client-side environment.
    const response = await fetch(`https://noembed.com/embed?url=${encodeURIComponent(url)}`);
    if (!response.ok) {
      throw new Error('Failed to fetch video data. The URL might be invalid or private.');
    }
    const data = await response.json();
    if (data.error) {
        throw new Error(data.error);
    }
    if (!data.title) {
        throw new Error('Could not extract a title from the provided YouTube URL.');
    }
    return {
      title: data.title,
      author_name: data.author_name,
      thumbnail_url: data.thumbnail_url,
    };
  } catch (error) {
    console.error('Error fetching YouTube metadata:', error);
    throw new Error(error instanceof Error ? error.message : 'An unknown error occurred while fetching video details.');
  }
};
