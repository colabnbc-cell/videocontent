/**
 * Extracts a specified number of frames from a video file as base64 encoded JPEG strings.
 * This new implementation is more robust and uses an async loop for better reliability.
 * @param videoFile The video file to process.
 * @param maxFrames The maximum number of frames to extract.
 * @returns A promise that resolves to an array of base64 encoded frame strings.
 */
export const extractFramesFromVideo = (
  videoFile: File,
  maxFrames: number
): Promise<string[]> => {
  return new Promise((resolve, reject) => {
    const video = document.createElement('video');
    const canvas = document.createElement('canvas');
    const context = canvas.getContext('2d');
    const frames: string[] = [];

    if (!context) {
      return reject(new Error('Could not get canvas context.'));
    }

    // Hide video element to prevent it from showing up in the DOM
    video.style.display = 'none';

    const revokeUrl = () => {
      if (video.src) {
        URL.revokeObjectURL(video.src);
      }
       if (video.parentNode) {
        video.parentNode.removeChild(video);
      }
    };

    video.onloadedmetadata = async () => {
      if (!isFinite(video.duration) || video.duration === 0) {
        revokeUrl();
        return reject(
          new Error(
            'Video duration is invalid or could not be determined. The file may be corrupt.'
          )
        );
      }

      // Add video to DOM to ensure it can play in some browsers
      document.body.appendChild(video);

      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const duration = video.duration;
      // Ensure we don't try to extract a frame at the very end
      const interval = duration / (maxFrames > 1 ? maxFrames : 1);

      for (let i = 0; i < maxFrames; i++) {
        const time = i * interval;
        video.currentTime = time;

        try {
          await new Promise<void>((resolveSeek, rejectSeek) => {
            const seekTimeout = setTimeout(() => {
                rejectSeek(new Error(`Seeking to ${time.toFixed(2)}s timed out.`));
            }, 10000); // 10 second timeout for seek

            const onSeeked = () => {
              clearTimeout(seekTimeout);
              video.removeEventListener('seeked', onSeeked);
              // A short delay for the frame to be painted, especially on heavy videos
              setTimeout(resolveSeek, 100);
            };
            
            video.addEventListener('seeked', onSeeked);
          });

          context.drawImage(video, 0, 0, video.videoWidth, video.videoHeight);
          const dataUrl = canvas.toDataURL('image/jpeg', 0.8);
          // remove the "data:image/jpeg;base64," part
          frames.push(dataUrl.substring(dataUrl.indexOf(',') + 1));
        } catch (e) {
            console.error(e);
            // If one frame fails, we can try to continue with the others
        }
      }

      revokeUrl();
      resolve(frames);
    };

    video.onerror = (e) => {
      revokeUrl();
      reject(
        new Error(
          'Error loading or processing video file. It might be corrupted or in an unsupported format.'
        )
      );
    };

    video.preload = 'auto';
    video.src = URL.createObjectURL(videoFile);
    video.muted = true;
    video.playsInline = true;
    video.load();
    video.play().catch(() => {
        // Play is sometimes required to enable seeking on some mobile browsers.
        // We can ignore the error if autoplay is blocked.
    });
  });
};